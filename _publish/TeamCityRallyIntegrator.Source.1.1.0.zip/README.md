TeamCityRallyIntegration
========================

This is a plugin for TeamCity which integrates TeamCity with Rally. 

package com.rally.integration.rally.entities;

public class RallyRepository extends RallyObject implements IRallyObject {

    public RallyRepository(String name, String ref) {
        super(name, ref);
    }
}

package com.rally.integration.rally.entities;

public interface IRallyObject {
    String getRef();
}
